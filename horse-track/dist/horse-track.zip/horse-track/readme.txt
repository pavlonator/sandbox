* what is this
---------------------------------

This a horse track ATM emulator console application


* how to un it
---------------------------------

rename file bin/horse-track.renametojar ->bin/horse-track.jar

to run the program on windows use:
    run.bat

for linux/unix:
    run.sh

from IDE: start com.horsetrack.HorseTrackStart class

Note: if your system configured to auto-run jar files, simply double click on it.


* what is included
---------------------------------

bin folder contain binary distribution along with auxiliary run scripts
src folder contain source code
readme.txt - this file
